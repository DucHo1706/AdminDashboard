Website Quản lý đặt vé xe sử dụng asp.net sql sever 
Công nghệ sử dụng: Asp.net ngôn ngữ c#, database SqlSever , Host SQL SERVER Monsterasp.net
Tài liệu Đồ án 
Link DBcontext 
Fluent API 
https://learn.microsoft.com/en-us/ef/ef6/modeling/code-first/fluent/types-and-properties

Thư viện cần tải 
<img width="2877" height="1689" alt="image" src="https://github.com/user-attachments/assets/c824e419-a4cb-4486-bb3b-43e7d0d4d62a" />
<img width="1320" height="296" alt="image" src="https://github.com/user-attachments/assets/25f3c395-c65f-4c9c-a76a-e165b2d74211" />
"Chức Năng Cần làm "
Ban quản trị:
Đăng nhập

Thêm xóa sửa

Đăng xuất

Quản lý vé

Quản lý bài viết

Quản lý tài khoản khách hàng

Quản lý menu

Quản lý đơn hàng

Quản lý lịch trình chuyến đi

Quản lý thông tin cá nhân

Thành viên:
Đăng nhập

Đăng xuất

Tìm kiếm

Đặt vé

Hủy Vé

Thanh toán

Lịch sử đặt vé

Xem chi tiết vé và chuyến đi

Xem danh sách chuyến đi trong ngày

Xem danh sách tất cả chuyến đi

Quản lý thông tin cá nhân

Khách:
Xem vé (xem chuyến đi)

Tạo tài khoản

Tìm kiếm

Xem bài viết

=====================================================

"Chức Năng Đã có "
Đăng nhập
Đăng ký 
Đăng xuất 
